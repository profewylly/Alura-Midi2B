document.querySelector('.tecla_pom');

document.querySelector('#som_tecla_pom').play();

